({
    setColumns: function(cmp) {
        var columns = [];
        if(cmp.get("v.ShowCommunityName") == true){
            columns.push({ label: 'Vendor Community Name',editable: true,fieldName: 'Name',type:'text',sortable: true });
        }
        if(cmp.get("v.ShowPOName") == true){
            columns.push({label: 'PO Name',fieldName: 'PO_Name__c',editable: true,sortable: true });
        }
        if(cmp.get("v.ShowVendorInvoiceDate") == true){
            columns.push({ label: 'Vendor Invoice Date',editable: true, fieldName: 'Vendor_Invoice_Date__c',sortable: true });
        }
        if(cmp.get("v.ShowVendorInvoiceNumber") == true){
            columns.push({ label: 'Vendor Invoice Number',editable: true, fieldName: 'Vendor_Invoice_number__c',sortable: true });
        }
        if(cmp.get("v.ShowVendorInvoiceAmount") == true){
            columns.push({ label: 'Vendor Invoice Amount',editable: true, fieldName: 'Vendor_Invoice_Amount__c',sortable: true });
        }
        if(cmp.get("v.ShowCost") == true){
            columns.push( { label: 'Cost', fieldName: 'Cost__c',editable: true,sortable: true,type: 'currency' });
        }
        if(cmp.get("v.ShowInrangePM") == true){
            columns.push(  { label: 'inRange PM',editable: true,fieldName: 'inRange_PM__c',sortable: true });
        }
        if(cmp.get("v.ShowAmountPaidToVendor") == true){
            columns.push(  { label: 'Amount Paid to Vendor',editable: true,fieldName: 'Amount_Paid_to_Vendor__c',sortable: true });
        }
        if(cmp.get("v.ShowPaymentCheckNumber") == true){
            columns.push(  { label: 'Payment Check Number',editable: true,fieldName: 'Payment_Check_Number__c',sortable: true });
        }
        if(cmp.get("v.ShowProjectName") == true){
            columns.push(  { label: 'Project Name',editable: true,fieldName:'Project_Name__c',sortable: true });
        }
        if(cmp.get("v.ShowSiteName") == true){
            columns.push(  { label: 'Site Name',editable: true,fieldName:'Site_Name__c',sortable: true });
        }
        if(cmp.get("v.ShowStatus") == true){
            columns.push(  { label:'Status',editable: true,fieldName:'Status__c',sortable: true });
        }
        if(cmp.get("v.ShowVendorInvoicePaidDate") == true){
            columns.push(  { label: 'Vendor Invoice Paid Date',editable: true,fieldName: 'Vendor_Invoice_Paid_Date__c',sortable: true });
        }
        cmp.set('v.columns',columns);
        // this.COLUMNS
    },
    updateCommunityVendor : function(component,jsonstr){debugger;
        console.log('@@@ jsonstr' + jsonstr);
        var action = component.get("c.updateData"); 
        action.setParams({
            "strfromlex" : jsonstr
        });
        console.log("setParams has actived");
        action.setCallback(this, function(response) {
            console.log('@@@ SetCallback !');
            var state = response.getState();
            //alert(state);
             console.log('state',state);
             console.log('response.getReturnValue()',response.getReturnValue());
            if (state === "SUCCESS") {
                component.set("v.importData", false); 
                var resultsToast = $A.get("e.force:showToast");
                var returnresponse = response.getReturnValue();
                if(returnresponse == 'SUCCESS'){
                resultsToast.setParams({
                    "title": "Success!",
                    "type": "success",
                    "message": "invoices has been updated."
                });
                }else{
                    resultsToast.setParams({
                    "title": "Error",
                    "type": "error",
                    "message": returnresponse
                });
                }
                resultsToast.fire(); 
                component.set("v.spinner", false);
                $A.get('e.force:refreshView').fire();
                 
                
                //var wasDismissed = $A.get("e.force:closeQuickAction");
                //wasDismissed.fire();            
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                    errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                    alert('Unknown');
                }
            }
        }); 
        $A.enqueueAction(action);
    },
    CSV2JSON: function (component,csv) {debugger;
        console.log('@@@ Incoming csv = ' + csv);
        
        //var array = [];
        var arr = []; 
        
        arr =  csv.split('\n');;
        //console.log('@@@ Array  = '+array);
        console.log('@@@ arr = '+arr);
        arr.pop();
        var jsonObj = [];
        var headers = arr[0].split(',');
        for(var i = 1; i < arr.length; i++) {
            var data = arr[i].split(',');
            var obj = {};
            for(var j = 0; j < data.length; j++) {
                obj[headers[j].trim()] = data[j].trim();
                //console.log('@@@ obj headers = ' + obj[headers[j].trim()]);
            }
            jsonObj.push(obj);
        }
        console.log('jsonobj',jsonObj);
        var json = JSON.stringify(jsonObj);
        console.log('@@@ json = '+ json);
        return json;
        
        
    },
    setData: function(cmp) {
        var action = cmp.get("c.fetchVC");
        var pageSize = cmp.get("v.pageSize").toString();
        var pageNumber = cmp.get("v.pageNumber").toString();
        action.setParams({
            'pageSize' : pageSize,
            'pageNumber' : pageNumber
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('response.getReturnValue()----',response.getReturnValue());
            if(response.getReturnValue().length >0){
                cmp.set("v.dataNmber",response.getReturnValue().length);
                cmp.set("v.disableBtn",false);
            }
            if (state === "SUCCESS") {
                var resultData = response.getReturnValue();
                if(resultData.length < cmp.get("v.pageSize")){
                    cmp.set("v.isLastPage", true);
                } else{
                    cmp.set("v.isLastPage", false);
                }
                cmp.set("v.dataSize", resultData.length);
                cmp.set("v.data", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
        //cmp.set('v.data', this.DATA);
    },
    
    sortData : function(component,fieldName,sortDirection){debugger;
        var data = component.get("v.data");
        //function to return the value stored in the field
        var key = function(a) { return a[fieldName]; }
        var reverse = sortDirection == 'asc' ? 1: -1;
        
        // to handel number/currency type fields 
        if(fieldName == 'Vendor_Invoice_Amount__c' || fieldName == 'Cost__c'){ 
            console.log('inside if');
            data.sort(function(a,b){
                var a = key(a) ? key(a) : '';
                var b = key(b) ? key(b) : '';
                return reverse * ((a>b) - (b>a));
            }); 
        }
        else{// to handel text type fields 
            data.sort(function(a,b){ 
                console.log('inside else');
                var a = key(a) ? key(a).toLowerCase() : '';//To handle null values , uppercase records during sorting
                var b = key(b) ? key(b).toLowerCase() : '';
                return reverse * ((a>b) - (b>a));
            });    
        }
        //set sorted data to accountData attribute
        component.set("v.data",data);
    },
    
    
    
    convertArrayOfObjectsToCSV : function(component,objectRecords){
        // declare variables
        var csvStringResult, counter, keys, columnDivider, lineDivider;
        
        // check if "objectRecords" parameter is null, then return from function
        if (objectRecords == null || !objectRecords.length) {
            return null;
        }
        // store ,[comma] in columnDivider variabel for sparate CSV values and 
        // for start next line use '\n' [new line] in lineDivider varaible  
        columnDivider = ',';
        lineDivider =  '\n';
        
        // in the keys valirable store fields API Names as a key 
        // this labels use in CSV file header  
        keys = ['Name','PO_Name__c','Vendor_Invoice_number__c','Vendor_Invoice_Amount__c','Id' ];
        
        csvStringResult = '';
        csvStringResult += keys.join(columnDivider);
        csvStringResult += lineDivider;
        
        for(var i=0; i < objectRecords.length; i++){   
            counter = 0;
            
            for(var sTempkey in keys) {
                var skey = keys[sTempkey] ;  
                
                // add , [comma] after every String value,. [except first]
                if(counter > 0){ 
                    csvStringResult += columnDivider; 
                }   
                
                csvStringResult += '"'+ objectRecords[i][skey]+'"'; 
                
                counter++;
                
            } // inner for loop close 
            csvStringResult += lineDivider;
        }// outer main for loop close 
        
        // return the CSV formate String 
        return csvStringResult;        
    },
})