({
    init: function(cmp, event, helper) {
        helper.setColumns(cmp);
        helper.setData(cmp);
        // helper.onLoad(cmp, event);
    },
    clearAllFilters : function(cmp, event, helper) {
        helper.setData(cmp);
    },
    importCsv : function(component,event,helper){
        component.set("v.spinner", true);                                          
        var fileInput = component.find("file").get("v.files");
        var file = fileInput[0];
        //alert(file);
        if (file) {
            console.log("File");
            var reader = new FileReader();
            reader.readAsText(file, "UTF-8");
            reader.onload = function (evt) {
                console.log("EVT FN");
                var csv = evt.target.result;
                console.log('@@@ csv file contains'+ csv);
                var result = helper.CSV2JSON(component,csv);
                console.log('@@@ result = ' + result);
                //console.log('@@@ Result = '+JSON.parse(result));
                helper.updateCommunityVendor(component,result);
            }
            reader.onerror = function (evt) {
                console.log("error reading file");
            }
        }
        
    },
    handleClick : function (cmp, event) {
        cmp.set("v.isOpen",true);
    },
    importData : function (cmp, event) {
        cmp.set("v.importData",true);
    },
    addFilter : function (cmp, event) {
        cmp.set("v.addFilter",true);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
        component.set("v.importData", false);
    },
    downloadCsv : function(component,event,helper){
        var VcList = component.get("v.VcList");
        
        var stockData = component.get("v.data");
        // call the helper function which "return" the CSV data as a String  
        if(VcList.length>0){ 
            var csv = helper.convertArrayOfObjectsToCSV(component,VcList); 
        }else{
            var csv = helper.convertArrayOfObjectsToCSV(component,stockData); 
        }
        if (csv == null){return;} 
        var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD, hh:mm:ss a");
        // ####--code for create a temp. <a> html tag [link tag] for download the CSV file--####     
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_self'; // 
        hiddenElement.download = 'ExportData.csv'+today;  // CSV file Name* you can change it.[only name not .csv] 
        document.body.appendChild(hiddenElement); // Required for FireFox browser
        hiddenElement.click(); // using click() js function to download csv file
    },
    updateSelectedText: function (cmp, event) {
        var selectedRows = event.getParam('selectedRows');
        var setRows = [];
        for (var i = 0; i < selectedRows.length; i++){
            setRows.push(selectedRows[i].Id);
        }
        cmp.set('v.SelectedIds',setRows);
        var selectedIds = cmp.get('v.SelectedIds');
        console.log('setRowsIds',selectedIds);
        console.log('selectedIds.length',selectedIds.length)
        if(selectedIds.length>0){
            var action = cmp.get('c.fetchVC');
            action.setParams({
                selectedRows : selectedIds
            });
            action.setCallback(this, function(response){
                //store state of response
                var state = response.getState();
                if (state === "SUCCESS") {
                    //set response value in ListOfVC attribute on component.
                    console.log('response.getReturnValue()',response.getReturnValue());
                    cmp.set('v.VcList',response.getReturnValue());
                    console.log('VcList',cmp.get('v.VcList'));
                }
            });
            $A.enqueueAction(action);
        }
    },
    handleFilesChange: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
            component.set("v.disabled",false);
        }
        component.set("v.fileName", fileName);
    },
    showSpinner: function(component, event, helper) {
        component.set("v.spinner", true); 
    },
    hideSpinner : function(component,event,helper){
        component.set("v.spinner", false);
    },
    SaveFilter : function(component,event,helper){debugger;
        var fieldapiname = component.find("field").get("v.value");
        let sltCmp = component.find("field");
        var test = sltCmp.get("v.validity").valid;
        console.log('test',test);
        if(sltCmp.get("v.validity").valid){ //Magic happens here
            var type = component.get("v.Datatype");
            if(type == 'String' || type == 'Picklist'){
                var operator = component.find("opertor").get("v.value");
            } 
            if(type == 'Currency' || type == 'Date'){
                var operator = component.find("optrCurr").get("v.value");
            } 
            
            var value;
            if(type == 'String' || type == 'Currency' ){                                          
                value = component.find("value").get("v.value");
            }
            if(type == 'Picklist'){
                console.log('inRangePM',component.get("v.inRangePM"));
                value = component.find("inRangePm").get("v.value");                 
            }
            if(type == 'Date'){
                value = component.find("date").get("v.value");                 
            }
            var pageSize = component.get("v.pageSize").toString();
            var pageNumber = component.get("v.pageNumber").toString();
            
            var action = component.get('c.fetchVC');
            action.setParams({
                fieldApiName : fieldapiname,
                Operator : operator,
                Value : value,
                pageSize : pageSize,
                pageNumber : pageNumber
                
            });  
            action.setCallback(this, function(response){
                //store state of response
                component.set("v.isOpen", false); 
                var state = response.getState();
                if (state === "SUCCESS") {
                    //set response value in ListOfVC attribute on component.
                    console.log('response.getReturnValue()',response.getReturnValue());
                    var resultData = response.getReturnValue();
                    if(resultData.length < component.get("v.pageSize")){
                        component.set("v.isLastPage", true);
                    } else{
                        component.set("v.isLastPage", false);
                    }
                    component.set("v.spinner", false); 
                    component.set('v.data',response.getReturnValue());
                    console.log('VcList',component.get('v.data'));
                    
                }
            });
            $A.enqueueAction(action); 
        }else{
            sltCmp.showHelpMessageIfInvalid(); //This will show validation messages for user. 
            return;
        }
        
        
    },
    onChange : function (cmp, evt, helper) {
        var apiname = cmp.find('field').get('v.value');
        var action = cmp.get("c.getType"); 
        action.setParams({
            "objName" : 'Vendor_Community__c',
            "FieldApiName" : apiname
        });   
        action.setCallback(this, function(response){
            var state = response.getState();
            var res = response.getReturnValue();
            console.log('res',res);
            if (state === "SUCCESS") {
                cmp.set("v.Datatype", res.Type);
                cmp.set("v.options", res.Options);
            }
        });
        $A.enqueueAction(action);
    },
    handleSort : function(component,event,helper){
        //Returns the field which has to be sorted
        var sortBy = event.getParam("fieldName");
        console.log('sortBy',sortBy);                                         
        //returns the direction of sorting like asc or desc
        var sortDirection = event.getParam("sortDirection");
        console.log('sortDirection',sortDirection); 
        //Set the sortBy and SortDirection attributes
        component.set("v.sortBy",sortBy);
        component.set("v.sortDirection",sortDirection);
        // call sortData helper function
        helper.sortData(component,sortBy,sortDirection);
    },
    handleNext : function(component, event, helper) { 
        var pageNumber = component.get("v.pageNumber");
        component.set("v.pageNumber", pageNumber+1);
        helper.setData(component, helper);
    },
    
    handlePrev : function(component, event, helper) {        
        var pageNumber = component.get("v.pageNumber");
        component.set("v.pageNumber", pageNumber-1);
        helper.setData(component, helper);
    },
    
    
});